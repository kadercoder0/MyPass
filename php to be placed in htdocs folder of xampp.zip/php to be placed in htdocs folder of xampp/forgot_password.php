<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Database connection
$db = new mysqli("localhost", "root", "", "mypass");

if ($db->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed: " . $db->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'] ?? '';
$email = trim($data['email']) ?? null;

if ($action === 'validate_email') {
    // Step 1: Validate Email
    $query = $db->prepare("SELECT security_question_1, security_question_2, security_question_3 FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        echo json_encode([
            "success" => true,
            "questions" => [
                $user["security_question_1"],
                $user["security_question_2"],
                $user["security_question_3"]
            ]
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Email not found."]);
    }
    $query->close();

} elseif ($action === 'validate_answers') {
    // Step 2: Validate Answers
    $answers = $data['answers'];
    $query = $db->prepare("SELECT security_answer_1, security_answer_2, security_answer_3 FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Trim inputs and ensure proper comparison
        $isValid = password_verify(trim($answers[0]), $user['security_answer_1']) &&
                   password_verify(trim($answers[1]), $user['security_answer_2']) &&
                   password_verify(trim($answers[2]), $user['security_answer_3']);

        if ($isValid) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "message" => "Security answers are incorrect."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "User not found."]);
    }
    $query->close();

} elseif ($action === 'update_password') {
    // Step 3: Update Password
    $newPassword = password_hash(trim($data['newPassword']), PASSWORD_BCRYPT);
    $query = $db->prepare("UPDATE users SET password = ? WHERE email = ?");
    $query->bind_param("ss", $newPassword, $email);

    if ($query->execute()) {
        echo json_encode(["success" => true, "message" => "Password updated successfully."]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update password."]);
    }
    $query->close();
}

$db->close();
?>
