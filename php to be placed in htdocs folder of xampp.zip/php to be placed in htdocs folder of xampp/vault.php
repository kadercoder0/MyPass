<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Database connection
$db = new mysqli("localhost", "root", "", "mypass");

if ($db->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed: " . $db->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'] ?? '';
$userId = $data['user_id'] ?? null;

define('ENCRYPTION_KEY', 'your_secret_key'); // You should store this securely

// Encryption function
function encrypt($data) {
    return openssl_encrypt($data, 'AES-128-ECB', ENCRYPTION_KEY);
}

// Decryption function
function decrypt($data) {
    return openssl_decrypt($data, 'AES-128-ECB', ENCRYPTION_KEY);
}

$sensitiveFields = [
    "Login" => ["Username", "Password"],
    "CreditCard" => ["Card Number", "Expiry Date", "CVV"],
    "SecureNote" => ["Note"], // Add more if needed
    "Identity" => ["Document Number", "Expiry Date"]
];

if ($action === 'create') {
    $type = $data['type'];
    $itemData = $data['data'];

    // Encrypt sensitive fields
    foreach ($itemData as $field => $value) {
        if (in_array($field, $sensitiveFields[$type] ?? [])) {
            $itemData[$field] = encrypt($value);
        }
    }

    $itemDataJson = json_encode($itemData);
    $query = $db->prepare("INSERT INTO vault_items (user_id, type, data) VALUES (?, ?, ?)");
    $query->bind_param("iss", $userId, $type, $itemDataJson);

    if ($query->execute()) {
        echo json_encode(["success" => true, "message" => "Item created successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to create item: " . $query->error]);
    }
    $query->close();
} elseif ($action === 'read') {
    $query = $db->prepare("SELECT id, type, data FROM vault_items WHERE user_id = ?");
    $query->bind_param("i", $userId);

    if ($query->execute()) {
        $result = $query->get_result();
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $itemData = json_decode($row['data'], true);

            // Decrypt sensitive fields
            foreach ($itemData as $field => $value) {
                if (in_array($field, $sensitiveFields[$row['type']] ?? [])) {
                    $itemData[$field] = decrypt($value);
                }
            }

            $items[] = [
                'id' => $row['id'],
                'type' => $row['type'],
                'data' => json_encode($itemData)
            ];
        }

        echo json_encode(["success" => true, "items" => $items]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to fetch items: " . $query->error]);
    }
    $query->close();
} elseif ($action === 'update') {
    $itemId = $data['id'];
    $itemData = $data['data'];

    // Log incoming update data for debugging
    error_log("Updating item with ID: " . $itemId . " and data: " . json_encode($itemData));

    // Encrypt sensitive fields
    foreach ($itemData as $field => $value) {
        if (in_array($field, $sensitiveFields[$data['type']] ?? [])) {
            $itemData[$field] = encrypt($value);
        }
    }

    $itemDataJson = json_encode($itemData);
    $query = $db->prepare("UPDATE vault_items SET data = ? WHERE id = ? AND user_id = ?");
    $query->bind_param("sii", $itemDataJson, $itemId, $userId);

    if ($query->execute()) {
        echo json_encode(["success" => true, "message" => "Item updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update item: " . $query->error]);
    }
    $query->close();
} elseif ($action === 'delete') {
    $itemId = $data['id'];

    $query = $db->prepare("DELETE FROM vault_items WHERE id = ? AND user_id = ?");
    $query->bind_param("ii", $itemId, $userId);

    if ($query->execute()) {
        echo json_encode(["success" => true, "message" => "Item deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to delete item: " . $query->error]);
    }
    $query->close();
}

$db->close();
?>
