<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Database connection
$db = new mysqli("localhost", "root", "", "mypass");

if ($db->connect_error) {
    die(json_encode(["error" => "Database connection failed: " . $db->connect_error]));
}

// Get the data from the request
$data = json_decode(file_get_contents("php://input"), true);

// Extract input data
$email = trim($data["email"]);
$password = password_hash(trim($data["password"]), PASSWORD_BCRYPT); // Hash the password

// Extract and hash security answers
$security_question_1 = trim($data["securityQuestions"][0]);
$security_answer_1 = password_hash(trim($data["securityAnswers"][0]), PASSWORD_BCRYPT);
$security_question_2 = trim($data["securityQuestions"][1]);
$security_answer_2 = password_hash(trim($data["securityAnswers"][1]), PASSWORD_BCRYPT);
$security_question_3 = trim($data["securityQuestions"][2]);
$security_answer_3 = password_hash(trim($data["securityAnswers"][2]), PASSWORD_BCRYPT);

// Insert data into the database
$query = $db->prepare("INSERT INTO users (email, password, security_question_1, security_answer_1, security_question_2, security_answer_2, security_question_3, security_answer_3) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$query->bind_param(
    "ssssssss",
    $email,
    $password,
    $security_question_1,
    $security_answer_1,
    $security_question_2,
    $security_answer_2,
    $security_question_3,
    $security_answer_3
);

if ($query->execute()) {
    echo json_encode(["message" => "User registered successfully."]);
} else {
    echo json_encode(["error" => "Registration failed: " . $query->error]);
}

$query->close();
$db->close();
?>
